basic calculator nothing more
